import tavernmag as tv 

comp_simple_wtpt = {"H2O": 79,
                    "CO2": 15,
                    "S":   6}

sample = tv.MagmaticFluid(comp_simple_wtpt, units='wtpercent')

sample.get_simplified_fluid_composition()

specs = tv.calculate_speciation(sample=sample, pressure=1000, temperature=1000, fO2_buffer='QFM', fO2_delta=1).result

specs.get_composition()

specs.get_simplified_fluid_composition()

specs2 = tv.calculate_speciation(sample=specs, pressure=1000, temperature=1000, fO2_buffer='QFM', fO2_delta=1).result
specs2.get_composition()
specs2.get_simplified_fluid_composition()